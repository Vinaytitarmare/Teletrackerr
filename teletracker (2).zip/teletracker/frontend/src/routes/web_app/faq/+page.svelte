
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<style>
    body {
      font-family: 'Poppins', sans-serif;
    }
    .hide-scrollbar::-webkit-scrollbar{
  display: none;
    }
    .hide-scrollbar{
      -ms-overflow-style:none;
      scrollbar-width: none;
    }
  </style>  

<!-- <div class=" h-[1200px] " > -->
<!-- search bar and profile -->
<div class="fixed top-0 left-[16rem] right-0 shadow z-40 bg-[#d9d9d9] ">
<div class="flex justify-between items-center p-3">
  <input 
    type="search" 
    placeholder="Search employees" 
    class="search border border-gray-300 focus:border-black focus:outline-none focus:ring-0 transition-all duration-150 ml-2 mt-2 pl-10 rounded-full h-10 w-[60%] bg-no-repeat bg-left bg-center bg-x-[20px] bg-[url('/icon/search.png')] bg-[length:35px]">
  
  <div class="flex gap-3">
    <div class="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#bfbdbc]">
      <i class="fa-regular fa-bell text-2xl"></i>
    </div>
    <div class="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#bfbdbc]">
      <img src="/icon/messenger.png" class="max-w-full max-h-full pt-1" alt="">
    </div>
    <div class="w-10 h-10 rounded-full flex items-center justify-center bg-white hover:bg-[#bfbdbc]">
      <i class="fa-solid fa-user"></i>
    </div>
  </div>
</div>
</div>

<!--  -->
<!-- MAIN PART HERE BHAIYAA -->
 <div class=" flex z-20">
<div class="main_part ml-[16rem] mt-20 z-20 w-[80%] p-0 h-[89vh] overflow-y-scroll pr-4 hide-scrollbar">
<!-- feed -->

<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
<div class="feed w-[90%] h-[60vh] bg-[#bfbdbc] mx-8 my-10 rounded-2xl"></div>
</div>


<!-- newsfeed -->
<div class="newsfeed h-[80vh] bg-[#e6e6e6] mt-28 w-[40%] rounded-2xl mr-3">
<div><p class="text-lg font-bold px-6 pt-3">Newsfeeds</p></div>
<div class="h-[90%] overflow-y-scroll hide-scrollbar">
  <div class="news h-[30vh] bg-[#bfbdbc] w-[90%] mx-auto my-4 rounded-2xl"></div>
<div class="news h-[30vh] bg-[#bfbdbc] w-[90%] mx-auto my-4 rounded-2xl"></div>

<div class="news h-[30vh] bg-[#bfbdbc] w-[90%] mx-auto my-4 rounded-2xl"></div>

<div class="news h-[30vh] bg-[#bfbdbc] w-[90%] mx-auto my-4 rounded-2xl"></div>

<div class="news h-[30vh] bg-[#bfbdbc] w-[90%] mx-auto my-4 rounded-2xl"></div>

<div class="news h-[30vh] bg-[#bfbdbc] w-[90%] mx-auto my-4 rounded-2xl"></div>
</div>

</div>
</div>























<!--      
  <div class=" flex justify-between items-center  ">
      <input type="search" placeholder="Search alumni, students or professors" class="search  border border-gray-300 focus:border-black focus:outline-none focus:ring-0 transition-all duration-150   ml-10 mt-[15px] pl-10 rounded-full h-10 w-[60%] bg-no-repeat bg-left  bg-center bg-x-[20px] bg-[url('/icon/search.png')] bg-[length:35px]">
  
    <div class="float-right flex gap-3 mt-3">
   
      <div class="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#bfbdbc] "><i class="fa-regular fa-bell  text-2xl"></i></div>
      <div class="w-10 h-10 rounded-full flex items-center justify-center  hover:bg-[#bfbdbc]"><img src="/icon/messenger.png" class="max-w-full max-h-full pt-1" alt=""></div>
      <div class="w-10 h-10 rounded-full flex items-center justify-center bg-white mr-2 hover:bg-[#bfbdbc]"><i class="fa-solid fa-user"></i></div>
    </div>
</div> -->
















<!-- 
<script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body {
          font-family: 'Poppins', sans-serif;
        }
      </style>  


 
  <div class="fixed top-0 left-[16rem] right-0 shadow z-10 bg-[#d9d9d9] ">
    <div class="flex justify-between items-center p-3">
      <input 
        type="search" 
        placeholder="Search alumni, students or professors" 
        class="search border border-gray-300 focus:border-black focus:outline-none focus:ring-0 transition-all duration-150 ml-2 mt-2 pl-10 rounded-full h-10 w-[60%] bg-no-repeat bg-left bg-center bg-x-[20px] bg-[url('/icon/search.png')] bg-[length:35px]">
      
      <div class="flex gap-3">
        <div class="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#bfbdbc]">
          <i class="fa-regular fa-bell text-2xl"></i>
        </div>
        <div class="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#bfbdbc]">
          <img src="/icon/messenger.png" class="max-w-full max-h-full pt-1" alt="">
        </div>
        <div class="w-10 h-10 rounded-full flex items-center justify-center bg-white hover:bg-[#bfbdbc]">
          <i class="fa-solid fa-user"></i>
        </div>
      </div>
    </div>
  </div> -->
